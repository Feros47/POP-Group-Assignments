Navne: Niels Abildskov (vzn250), Niklas Marcussen (gwv160)
Dato for arbejde: 4. November 2023